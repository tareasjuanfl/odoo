## Module <auto_database_backup>

#### 07.05.2022
#### Version 15.0.1.0.0
#### ADD
- Initial commit for auto_database_backup

#### 14.06.2022
#### Version 15.0.2.0.1
#### ADD
- Dropbox integration added. Backup can be stored in to dropbox.

#### 20.08.2022
#### Version 15.0.3.0.1
#### ADD
- Onedrive integration added. Backup can be stored in to onedrive.

#### 15.11.2022
#### Version 15.0.3.1.1
#### ADD
- Google Drive authentication updated.

#### 16.10.2023
#### Version 15.0.4.1.2
#### ADD
- Nextcloud and Amazon S3 integration added. Backup can be stored into Nextcloud and Amazon S3.

#### 16.02.2024
#### Version 15.0.5.1.0
#### UPDT
- Fixed internal server error in Onedrive and Google Drive integration.

#### 24.04.2024
#### Version 15.0.6.1.0
#### UPDT

- Fixed the errors while inputting list_db = False in odoo conf file.