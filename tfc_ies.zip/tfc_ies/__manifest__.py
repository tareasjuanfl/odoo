# -*- coding: utf-8 -*-
{
    'name': "tfc_ies",
    'application': True,
    'summary': """
        Aplicación que permite administrar Proyectos - TFCs.""",

    'description': """
        Aplicación que permite administrar Proyectos - TFCs.
    """,

    'author': "Alvaro Martínez Cano. Tutor: Juan Fernández López",
    'website': "https://www.iesleonardodavinci.com/",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Educación',
    'version': '1.0',

    # any module necessary for this one to work correctly
    'depends': ['base'],

    # always loaded
    'data': [
		'security/security.xml',
        'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
        'reports/proyectos_por_curso_report.xml',
        'reports/proyectos_por_ciclo_report.xml',
        'reports/alumnos_report.xml',
        'reports/tutores_report.xml',
        'reports/proyectos_report.xml',
        ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
