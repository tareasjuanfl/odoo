# -*- coding: utf-8 -*-
# from odoo import http


# class TfcIes(http.Controller):
#     @http.route('/tfc_ies/tfc_ies/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/tfc_ies/tfc_ies/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('tfc_ies.listing', {
#             'root': '/tfc_ies/tfc_ies',
#             'objects': http.request.env['tfc_ies.tfc_ies'].search([]),
#         })

#     @http.route('/tfc_ies/tfc_ies/objects/<model("tfc_ies.tfc_ies"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('tfc_ies.object', {
#             'object': obj
#         })
