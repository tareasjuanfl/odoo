#-*- coding: utf-8 -*-

from odoo import models, fields, api
from odoo.exceptions import ValidationError
from datetime import datetime

class alumno(models.Model):
    _name = 'tfc.alumno'

    name = fields.Char(string="Nombre",required=True)
    apellidos = fields.Char(string="Apellidos",required=True)
    imagen = fields.Binary(string="Foto")
    telefono = fields.Integer(string="Teléfono")
    correo = fields.Char(string="Correo Electrónico")
    proyectos = fields.One2many("tfc.proyecto","alumno",string="Proyectos")

    def name_get(self):
        result = []
        for rec in self:
            result.append((rec.id, rec.apellidos + ", " + rec.name))
        return result


class tutor(models.Model):
    _name = 'tfc.tutor'

    name = fields.Char(string="Nombre",required=True)
    apellidos = fields.Char(string="Apellidos",required=True)
    telefono = fields.Integer(string="Teléfono")
    correo = fields.Char(string="Correo Electrónico")
    proyectos = fields.One2many("tfc.proyecto","tutor",string="Proyectos")

    def name_get(self):
        result = []
        for rec in self:
            result.append((rec.id, rec.apellidos + ", " + rec.name))
        return result

class curso(models.Model):
    _name = 'tfc.curso'

    name = fields.Char(string="Nombre",required=True)
    proyectos = fields.One2many("tfc.proyecto","curso",string="Proyectos")


class ciclo(models.Model):
    _name = 'tfc.ciclo'

    name = fields.Char(string="Nombre",required=True)
    proyectos = fields.One2many("tfc.proyecto","ciclo",string="Proyectos")

class palabraclave(models.Model):
    _name = 'tfc.palabraclave'

    name = fields.Char(string="Nombre",required=True)


class archivo(models.Model):
    _name = 'tfc.archivo'

    name = fields.Char(string="Nombre",required=True)
    descripcion = fields.Text(string="Descripción")
    fecha_subida = fields.Date(string="Fecha de subida",default=datetime.today())
    archivo = fields.Binary(string="Archivo",  store=True, attachment=True, required=True)
    file_name = fields.Char(string='File name')
    proyecto = fields.Many2one("tfc.proyecto",string="Proyecto",required=True)


class proyecto(models.Model):
    _name = 'tfc.proyecto'

    name = fields.Char(string="Nombre",required=True)
    alumno = fields.Many2one("tfc.alumno",string="Alumn@",required=True)
    tutor = fields.Many2one("tfc.tutor",string="Tutor/a",required=True)
    curso = fields.Many2one("tfc.curso",string="Curso",required=True)
    ciclo = fields.Many2one("tfc.ciclo",string="Ciclo",required=True)
    palabras_clave = fields.Many2many("tfc.palabraclave",string="Palabras Clave")
    descripcion = fields.Text(string="Descripción")
    evaluacion = fields.Char(string="Evaluación")
    comentarios = fields.Text(string="Comentarios")
    fecha_exposicion = fields.Date(string="Fecha de exposición")
    archivos = fields.One2many("tfc.archivo","proyecto",string="Archivos adjuntos")

    def name_get(self):
        result = []
        for rec in self:
            result.append((rec.id, rec.name +" - "+ rec.alumno.apellidos + ", " + rec.alumno.name))
        return result
